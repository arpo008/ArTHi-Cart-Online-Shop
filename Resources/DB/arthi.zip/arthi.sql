-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2025 at 07:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arthi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `email` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`email`, `pass`) VALUES
('tayhan@gmail.com', '1234'),
('arpo@gmail.com', '5678'),
('alamgir@gmail.com', '9876'),
('arthi@gmail.com', 'arthi');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `name`, `email`, `Age`, `address`, `pass`, `number`) VALUES
(1100, 'Tayhan', 'tayhan@gmail.com', 20, 'Dhaka', '1234', 1868364556),
(1101, 'Arpo', 'arpo@gmail.com', 21, 'Sylet', '5678', 1553702262),
(1102, 'Alamgir', 'alamgir@gmail.com', 23, 'Madaripur', '9123', 1536247943),
(1103, 'Rakib', 'rakib@gmail.com', 23, 'Joypurhat', '9638', 1368364456),
(1104, 'Sakib', 'sakib@gmail.com', 28, 'Rajshahi', '7412', 1753702262),
(1105, 'karim', 'karim@gmail.com', 25, 'Chadpur', '1234', 1753702262),
(1106, 'Lal babu', 'lal@gmail.com', 21, 'c Block', '12345', 178956856),
(1107, 'Nandu babu', 'nandu@gmail.com', 21, 'c Block', '2580', 178956857),
(1108, 'Iqbal', 'iqbal@gmail.com', 31, 'Rajshahi', '1234', 1789586986);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `pid` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`pid`, `name`, `address`, `email`, `age`, `role`) VALUES
(1, 'Karim', 'Rajshahi', 'karim@gmail.com', 24, 'Sell Manager'),
(2, 'Rahim', 'Dhaka', 'rahim@gmail.com', 28, 'IT Officer'),
(3, 'Hasan', 'Chittagong', 'hasan@gmail.com', 30, 'Accountant'),
(4, 'Rafi', 'Sylhet', 'rafi@gmail.com', 26, 'Sales Executive'),
(5, 'Sumon', 'Khulna', 'sumon@gmail.com', 31, 'Branch Manager'),
(6, 'Tuhin', 'Barisal', 'tuhin@gmail.com', 25, 'Support Staff'),
(7, 'Mim', 'Mymensingh', 'mim@gmail.com', 27, 'Sell Manager'),
(8, 'Jannat', 'Rangpur', 'jannat@gmail.com', 23, 'Marketing Officer'),
(9, 'Sadia', 'Narayanganj', 'sadia@gmail.com', 29, 'HR Officer'),
(10, 'Tanvir', 'Comilla', 'tanvir@gmail.com', 32, 'IT Officer'),
(11, 'Shuvo', 'Jessore', 'shuvo@gmail.com', 28, 'Sales Executive'),
(12, 'Niloy', 'Bogura', 'niloy@gmail.com', 33, 'Supervisor'),
(13, 'Anika', 'Noakhali', 'anika@gmail.com', 24, 'Support Staff'),
(14, 'Ovi', 'Dinajpur', 'ovi@gmail.com', 26, 'Accountant'),
(15, 'Lamia', 'Gazipur', 'lamia@gmail.com', 30, 'Marketing Officer'),
(16, 'Farhan', 'Tangail', 'farhan@gmail.com', 29, 'Branch Manager'),
(17, 'Rumi', 'Feni', 'rumi@gmail.com', 25, 'Sales Executive'),
(18, 'Rubel', 'Jamalpur', 'rubel@gmail.com', 34, 'Security'),
(19, 'Mahi', 'Kushtia', 'mahi@gmail.com', 22, 'Support Staff'),
(20, 'Sohan', 'Satkhira', 'sohan@gmail.com', 27, 'Supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `cid` int(11) DEFAULT NULL,
  `oid` int(11) DEFAULT NULL,
  `order_date` varchar(20) DEFAULT NULL,
  `delivery_date` varchar(20) DEFAULT NULL,
  `total_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`cid`, `oid`, `order_date`, `delivery_date`, `total_price`) VALUES
(1107, 3200, '11/05/2025', '18/05/2025', 300),
(1107, 3201, '11/05/2025', '18/05/2025', 1700),
(1107, 3202, '11/05/2025', '18/05/2025', 1501500),
(1107, 3203, '11/05/2025', '18/05/2025', 0),
(1108, 3204, '11/05/2025', '18/05/2025', 1501700);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `oid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`oid`, `pid`, `quantity`) VALUES
(3200, 2111, 1),
(3201, 2783, 1),
(3202, 2345, 1),
(3202, 2222, 1),
(3204, 2345, 1),
(3204, 2783, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_history`
--

CREATE TABLE `order_history` (
  `oid` int(11) DEFAULT NULL,
  `order_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_history`
--

INSERT INTO `order_history` (`oid`, `order_status`) VALUES
(3200, 'Order Cancel'),
(3201, 'Deliverd'),
(3202, 'Delivered'),
(3203, 'Delivered'),
(3204, 'Some Internal Issue. Delay 4-5 days');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` varchar(20) DEFAULT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `Name`, `Price`, `img`) VALUES
('2345', 'Iphone 16', 1500000, 'uploadimg/iPhone-15-Plus-(2)-(6)-5363.jpg'),
('2111', 'Charger', 300, 'uploadimg/charger.jpg'),
('2222', 'TWS', 1500, 'uploadimg/TWS.jpg'),
('2783', 'Normal Shoe', 1700, 'uploadimg/Normal Shoe.jpg'),
('2556', 'Nike Shoe', 1900, 'uploadimg/Nike Shoe.jpg'),
('2558', 'Canon Camera', 2000000, 'uploadimg/Camera.jpg'),
('2555', 'Murgi', 350, 'uploadimg/images.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `seller_details`
--

CREATE TABLE `seller_details` (
  `sid` int(11) DEFAULT NULL,
  `loc` varchar(50) DEFAULT NULL,
  `seller_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
